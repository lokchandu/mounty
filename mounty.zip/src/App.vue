<template>
  <div id="app">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
    <h1>Upcoming movies</h1>
    <ListMovies msg="Welcome to movies list" apikey="ef342afd9c205151529852466e2432d2" movieitem="upcoming"/>
    <h1>Top Rated movies</h1>
    <ListMovies msg="Welcome to movies list" apikey="ef342afd9c205151529852466e2432d2" movieitem="top_rated"/>
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import ListMovies from './components/ListMovies.vue'
export default {
  name: 'App',
  components: {
    HelloWorld,
    ListMovies
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
