<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <ul id="example-1">
  <li v-for="item in movieslist" :key="item.message">
    {{ item.original_title }}
  </li>
</ul>
  </div>
</template>

<script>
import axios from 'axios';
export default {
    data(){
        return{
            movieslist : {}
        }
    },
  props: {
    msg: String,
    apikey: String,
    movieitem:String
  },
  mounted(){
      console.log("mounted")
     axios.get("https://api.themoviedb.org/3/movie/"+this.movieitem+"?api_key="+this.apikey)
    .then(response => {
        console.log( response.data.results)
        this.movieslist = response.data.results;
        })
  }
}
</script>
